package JavaPractice;

import java.util.*;
import java.util.Observer;

/**
 * 使用Java内置的观察者模式工具类实现观察者模式
 * 工具类位于java.util包内
 *
 * Created by 10192078 on 2017/3/6.
 */
public class ObserverTester2 {
    public static void main(String[] args) {
        Watched watched = new Watched();
        /**向主题类注册观察者*/
        Watcher watcher = new Watcher(watched);
        watched.setData("a");
        watched.setData("b");
        watched.setData("c");
    }
}

/**
 * 继承Observable类实现「具体主题实现类」
 * java.util.Observable提供两个公开的方法支持观察者对象
 * setChanged()和notifyObservers()
 *
 * setChanged(): 会设置一个内部标记变量，代表被观察者对象的状态发生了变化
 * notifyObservers(): 会调用所有登记过的观察者对象的update()方法，使这些观察对象可以更新自己
 */
class Watched extends Observable {
    public String getData() {
        return data;
    }

    public void setData(String data) {
        if (!data.equals(this.data)) {
            this.data = data;
            /***/
            setChanged();
        }
        /***/
        notifyObservers();
    }

    String data = "";
}


/**
 * 实现Observer类用以实现「具体观察者实现类」，需要重写其update方法
 *
 * note:构造函数中需要调用Observable.addObserver(this)把自己注册到主题类中
 */
class Watcher implements Observer {

    Watcher(Observable ob) {
        /***/
        ob.addObserver(this);
    }

    @Override
    public void update(Observable o, Object arg) {
        System.out.println(String.format("状态发生了改变：%s", ((Watched)o).getData()));
    }
}
