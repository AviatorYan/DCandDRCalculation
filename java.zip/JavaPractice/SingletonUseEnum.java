package JavaPractice;

/**
 * Created by 10192078 on 2017/4/6.
 */
public enum  SingletonUseEnum {
    getInstance; /*{
        @Override
        public void print() {
            System.out.println("abcdef");
        }
    };*/

    /*public abstract void print();*/

    private String name;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
