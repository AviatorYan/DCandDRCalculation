package JavaPractice;

import java.util.*;

/**
 * Created by 10192078 on 2017/2/17.
 */
public class run {

    public static <E> void printArray(E[] array) {
        for (E element:array) {
            System.out.printf("%s ", element);
        }
    }

    public static <T extends Comparable<T>> T getMaxNumber(T x, T y, T z) {
        T max = x.compareTo(y) > 0 ? (x.compareTo(z) > 0 ? x : z) : y;
        return max;
    }

    public static <E> void println(E arg) {
        System.out.println(arg);
    }

    public void someCode() {
        List<String> list = new ArrayList<String>();
        //List<String> list = new LinkedList<String>();
        list.add("abc");
        list.add("xyz");
        list.add("ijk");
        /** 集合转数组 */
        String[] array = list.toArray(new String[list.size()]);
        for (String str:array) {
            //System.out.println(str);
        }

        Set<String> set1 = new HashSet<String>(Arrays.asList(array));
        for (String str:set1) {
            //System.out.println(str);
        }

        Arrays.asList(list);

        Collections.reverse(list);


        for (String elem: list) {
            //System.out.println(elem);
        }

        Iterator<String> iter = list.iterator();
        while (iter.hasNext()) {
            String str = iter.next();
            //System.out.println(str);
        }

        Object[] array2 = list.toArray();
        for (int i=0; i<list.size(); i++) {
            //System.out.println(list.get(i));
            //System.out.println(array[i]);
        }

        System.out.println("------");

        String[] strArray = new String[list.size()];
        list.toArray(strArray);
        for (String str: strArray) {
            //System.out.println(str);
        }

        Vector<String> vector = new Vector<String>();
        vector.add("v");

        Map<String, String> map1 = new HashMap<String, String>();
        map1.put("a", "i");
        map1.put("b", "j");
        map1.put("c", "k");

        Map<String, String> map2 = new HashMap<String, String>();
        map2.put("a", "i");
        map2.put("b", "j");
        map2.put("c", "k");

        //System.out.println(map1.equals(map2));


        Integer[] integer = new Integer[]{1, 2,3};
        integer[0].intValue();
        Integer.valueOf(1);

        Integer[] integer2 = {1, 2, 3};
    }

    public static int sumCalc(int... ints) {
        int sum = 0;
        for (int i:ints) {
            sum += i;
        }
        return sum;
    }

    public static void main(String[] args) {
        System.out.println("----- BEGIN -----");

        /*String[] strArray = {"a", "b"};
        Integer[] intArray = {1, 2, 3};
        printArray(strArray);
        printArray(intArray);*/

        /*Integer max = getMaxNumber(3, 2, 6);
        println(max);*/

        /*Box<Integer> bi = new Box<Integer>();
        bi.add(1);
        println(bi.get());*/

        /*StringBuffer sb = new StringBuffer();
        sb.append("a");
        sb.append("s");
        println(sb);*/

        /*StringBuilder sbb = new StringBuilder();
        sbb.append("d");
        sbb.append("f");
        println(sbb);*/

        /*int sum = sumCalc(1, 2,3);
        println(sum);
*/

/*        util.Map<String, String> m = new util.Map<>();
        m.put("a", "abc");
        m.put("b", "abc");

        m.get("b") = "bb";*/


    }

}


