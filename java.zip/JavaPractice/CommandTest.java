package JavaPractice;

import org.apache.avro.generic.GenericData;

import java.util.ArrayList;
import java.util.List;

/**
 * 命令模式，主要有四种角色
 * 1. 接收者，具体执行操作的
 * 2. 抽象命令角色类
 * 3. 具体命令角色类
 * 4. 执行者
 *
 * 本来是可以直接直接创建AudioPlay的对象，然后调用play()等成员方法，
 * 但是为了向调用者隐藏掉具体实现，改为执行者执行相应的命令，我只负责给执行者KeyBoard对象发指令
 *
 * Created by 10192078 on 2017/3/9.
 */
public class CommandTest {
    public static void main(String[] args) {
        AudioPlay audioPlay = new AudioPlay();
        KeyBoard keyBoard = new KeyBoard();

        keyBoard.setPlayCommand(new PlayCommand(audioPlay));
        keyBoard.setBackCommand(new BackCommand(audioPlay));
        keyBoard.setReplayCommand(new ReplayCommand(audioPlay));
        keyBoard.setStopCommand(new StopCommand(audioPlay));

        keyBoard.play();
        keyBoard.back();
        keyBoard.replay();
        keyBoard.stop();

        System.out.println("-------------");

        MacroCommand macro = new MacroAudioCommand();
        macro.add(new PlayCommand(audioPlay));
        macro.add(new BackCommand(audioPlay));
        macro.add(new StopCommand(audioPlay));
        macro.execute();
    }
}

/**具体执行操作的「接收者」角色*/
class AudioPlay {

    public void play() {
        System.out.println("播放...");
    }

    public void back() {
        System.out.println("后退...");
    }

    public void replay() {
        System.out.println("重播...");
    }

    public void stop() {
        System.out.println("停止...");
    }
}

/**抽象命令角色类*/
interface Command {
    public void execute();
}

/**具体命令角色类*/
class PlayCommand implements Command {

    AudioPlay audioPlay = null;

    PlayCommand(AudioPlay audioPlay) {
        this.audioPlay = audioPlay;
    }

    @Override
    public void execute() {
        audioPlay.play();
    }
}

/**具体命令角色类*/
class BackCommand implements Command {
    AudioPlay backPlay = null;

    BackCommand(AudioPlay backPlay) {
        this.backPlay = backPlay;
    }

    @Override
    public void execute() {
        backPlay.back();
    }
}

/**具体命令角色类*/
class ReplayCommand implements Command {
    AudioPlay replayPlay = null;

    ReplayCommand(AudioPlay replayPlay) {
        this.replayPlay = replayPlay;
    }

    @Override
    public void execute() {
        replayPlay.replay();
    }
}

class StopCommand implements Command {

    AudioPlay stopPlay = null;

    StopCommand(AudioPlay stopPlay) {
        this.stopPlay = stopPlay;
    }

    @Override
    public void execute() {
        stopPlay.stop();
    }
}

/**请求者角色，负责发出具体操作指令*/
class KeyBoard {
    Command playCommand = null;
    Command backCommand = null;
    Command replayCommand = null;
    Command stopCommand = null;

    public void setPlayCommand(Command command) {
        this.playCommand = command;
    }

    public void setBackCommand(Command backCommand) {
        this.backCommand = backCommand;
    }

    public void setReplayCommand(Command replayCommand) {
        this.replayCommand = replayCommand;
    }

    public void setStopCommand(Command stopCommand) {
        this.stopCommand = stopCommand;
    }

    public void play() {
        playCommand.execute();
    }

    public void back() {
        backCommand.execute();
    }

    public void replay() {
        replayCommand.execute();
    }

    public void stop() {
        stopCommand.execute();
    }
}


/**-----宏操作显示------*/

interface MacroCommand extends Command {
    public void add(Command command);
    public void remove(Command command);
}

class MacroAudioCommand implements MacroCommand {
    public List<Command> commandList = new ArrayList<>();

    @Override
    public void add(Command command) {
        commandList.add(command);
    }

    @Override
    public void remove(Command command) {
        commandList.remove(command);
    }

    @Override
    public void execute() {

        /*for (Command command:commandList) {
            command.execute();
        }*/

        //commandList.forEach(command -> command.execute());

        commandList.forEach(Command::execute);
    }
}
