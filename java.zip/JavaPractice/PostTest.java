package JavaPractice;

import encrypt.MD5;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;

/**
 * Created by 10192078 on 2017/4/25.
 */
public class PostTest {
    /**
     * @param httpUrl: 请求接口
     * @param httpArg: 参数
     * @return 返回结果
     */
    public static String request(String httpUrl, String httpArg) {
        BufferedReader reader = null;
        String result = null;
        StringBuilder sbf = new StringBuilder();

        try {
            URL url = new URL(httpUrl);
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.setRequestMethod("POST");
            connection.setRequestProperty("Content-Type", "application/json");
            //connection.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
            connection.setDoOutput(true);
            connection.getOutputStream().write(httpArg.getBytes("UTF-8"));
            /*OutputStreamWriter out = new OutputStreamWriter(connection.getOutputStream());
            out.write("unit = day");
            out.write("time = 2016-08-12");
            out.write("mdnlist = [15308134443, 18981460130, 18981460130, 18080180113]");
            out.flush();
            out.close();*/

            connection.connect();
            InputStream is = connection.getInputStream();
            reader = new BufferedReader(new InputStreamReader(is, "UTF-8"));
            String strRead = null;
            while ((strRead = reader.readLine()) != null) {
                sbf.append(strRead);
                sbf.append("\r\n");
            }
            reader.close();
            result = sbf.toString();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return result;
    }


    public static void main(String[] args) {
        String appkey= "1DD5F361A7CABCDE349EE74E50D18887";
        String timestamp = "2017-04-2610:53:10";
        String username = "asdf";
        String sign = MD5.md5Sign(username, timestamp);
        String httpUrl = "http://localhost:26188/vmaxadvanced/api/user/batchuserterminal?appkey="+ appkey +"&timestamp=" + timestamp + "&sign=" + sign;
        String httpArg = "{\"unit\":\"day\", \"time\":\"2016-08-12\", \"mdnlist\":[\"15308134443\", \"18981460130\", \"18981460130\", \"18080180113\"]}";
        //String httpArg = "{unit:day, time:2016-08-12, mdnlist:[15308134443, 18981460130, 18981460130, 18080180113]}";
        String jsonResult = request(httpUrl, httpArg);
        System.out.println(jsonResult);
    }

}
