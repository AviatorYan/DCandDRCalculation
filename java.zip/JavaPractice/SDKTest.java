package JavaPractice;

import com.zte.api.sdk.*;
import com.zte.api.sdk.example.CustomListener;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by 10192078 on 2017/4/26.
 */
public class SDKTest {

    public static void getFile() {
        ApiServerConfigFactory serverFactory = new ApiServerConfigFactory();
        serverFactory.setServerInfo("localhost", 26186);

        ApiAuthorityConfigFactory authorityFactory = new ApiAuthorityConfigFactory();
        authorityFactory.setAppKey("1DD5F361A7CABCDE349EE74E50D18887");
        authorityFactory.setUsername("asdf");

        Map<String, String> parameterMap = new HashMap<>();
        parameterMap.put("unit", "day");
        parameterMap.put("time", "2016-05-10");
        parameterMap.put("mdnlist", "[15308134443, 18981460130, 18981460130, 18080180113]");

        ApiParameterConfigFactory parameterFactory = new ApiParameterConfigFactory();
        parameterFactory.setParameterMap(parameterMap);
        parameterFactory.setRequestUrl("/api/user/batchuserterminal");
        parameterFactory.setMethod("post");

        ApiResponseConfigFactory responseFactory = new ApiResponseConfigFactory();
        responseFactory.setMultiThreadDownloadOption(true, 2);

        ZteApiFactory apiFactory = new ZteApiFactory();
        apiFactory.setServerConfig(serverFactory.createServerConfig());
        apiFactory.setAuthorityConfig(authorityFactory.createAuthorityConfig());
        apiFactory.setParameterConfig(parameterFactory.createParameterConfig());
        apiFactory.setResponseConfig(responseFactory.createResponseConfig());
        apiFactory.setListener(new CustomListener());

        ZteApiService apiService = apiFactory.createService();
        apiService.run();
    }

    public static void main(String[] args) {
        getFile();
    }
}
