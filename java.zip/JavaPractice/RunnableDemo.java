package JavaPractice;

import redis.abc.Run;

/**
 * Created by 10192078 on 2017/2/22.
 */
public class RunnableDemo implements Runnable {
    @Override
    public void run() {
        Integer[] integer = new Integer[]{1, 2, 3, 4, 5, 6, 7, 8};
        for (int i:integer) {
            System.out.println(i);
            try {
                Thread.sleep(150);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }

    public static void main(String[] args) {
        Thread runOne = new Thread(new RunnableDemo());
        runOne.start();

        Thread runTwo = new Thread(new RunnableDemo());
        runTwo.start();
    }
}
