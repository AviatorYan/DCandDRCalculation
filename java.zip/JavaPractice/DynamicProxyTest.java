package JavaPractice;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import java.util.Arrays;

/**
 * 代理模式
 *
 * 如果你希望跟踪对某个类中方法的调用，或者希望度量这些调用的开销，那么你应该怎样做呢？这些代码肯定是你不希望将其合并到应用中的代码，因此代理使得你可以很容易地添加或移除它们。
 *
 * Created by 10192078 on 2017/3/9.
 */
public class DynamicProxyTest {
    public static void main(String[] args) {
        /*Animal1 catProxy = new AnimalProxy(new Cat());
        catProxy.whoAmI();
        catProxy.go();*/

        /**动态代理*/
        Cat cat = new Cat();
        Animal1 catProxy = (Animal1)Proxy.newProxyInstance(
                    Animal1.class.getClassLoader(),
                    new Class[]{Animal1.class},
                    new DynamicProxyHandler(cat)
                );
        catProxy.whoAmI();
        catProxy.go();
    }
}

interface Animal1 {
    public void whoAmI();
    public void go();
}

class Cat implements Animal1 {
    @Override
    public void whoAmI() {
        System.out.println("I'm a cat.");
    }

    @Override
    public void go() {
        System.out.println("I can run.");
    }
}

class AnimalProxy implements Animal1 {
    Animal1 animal = null;

    AnimalProxy(Animal1 animal) {
        this.animal = animal;
    }

    @Override
    public void whoAmI() {
        System.out.println("What are you?");
        this.animal.whoAmI();
    }

    @Override
    public void go() {
        System.out.println("How you go?");
        this.animal.go();
    }
}


/**----------动态代理----------*/

class DynamicProxyHandler implements InvocationHandler {
    private Object proxy;

    DynamicProxyHandler(Object proxy) {
        this.proxy = proxy;
    }

    @Override
    public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
        System.out.println(String.format("proxy: %s, method: %s, args: %s", proxy.getClass(), method, Arrays.toString(args)));
        return method.invoke(this.proxy, args);
    }
}
