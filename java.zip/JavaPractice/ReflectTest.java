package JavaPractice;

import com.sun.xml.internal.ws.wsdl.writer.document.ParamType;

import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

/**
 * Created by 10192078 on 2017/3/4.
 */
public class ReflectTest {

    /**
     * 获取类的类类型，并且通过类类型创建实例对象
     */
    public static void classType() {
        Person jack = new Person("Jack");

        /**c1,c2,c3都表示Person类的类类型*/
        /** 1. 任何类都有一个隐含的静态成员class */
        Class c1 = Person.class;
        /** 2. 通过类对象的getClass()方法获取类类型 */
        Class c2 = jack.getClass();
        System.out.println(c1 == c2);  //true
        /** 3.通过类的全称获取类类型 */
        Class c3 = null;
        try {
            c3 = Class.forName("JavaPractice.Person");
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
        System.out.println(c1 == c3);  //true
        System.out.println(c3);  //class JavaPractice.Person

        /** 通过类的类类型创建该类的对象实例，通过c1,c2,c3创建Person的对象实例 */
        try {
            /** 前提是：该类必须要有无参构造函数
             * 若没有无参构造函数，则运行时会报错
             * */
            Person peter = (Person)c1.newInstance();
            peter.setName("Peter");
        } catch (InstantiationException | IllegalAccessException e) {
            e.printStackTrace();
        }
    }

    /**
     * 运行时动态加载对应的类
     * note: 功能性的类尽量使用动态加载的方法
     * @param className
     */
    public static void classLoader(String className) {
        try {
            Class c = Class.forName(className);
            /**获取类加载器的名称*/
            c.getClassLoader().getClass().getName();
            Animal animal = (Animal)c.newInstance();
            animal.go();
        } catch (ClassNotFoundException | InstantiationException | IllegalAccessException e) {
            e.printStackTrace();
        }
    }

    /**
     * 获取类的信息，包括类类型、类成员函数(Method)、类成员变量(Field)、类构造函数(Constructor)
     * @param obj
     */
    public static void classInformation(Object obj) {
        /** 1. 基本数据类型的类类型 */
        Class c1 = int.class;
        Class c2 = String.class;
        Class c3 = double.class;
        Class c4 = Double.class;
        Class c5 = void.class;
        System.out.println(c1.getName());  //getName()会返回带上包名的完整类名
        System.out.println(c2.getName());
        System.out.println(c2.getSimpleName());  //getSimpleName()只返回类名
        System.out.println(c3.getName());
        System.out.println(c4.getName());
        System.out.println(c5.getName());

        System.out.println("-----");

        /**
         * 2. 通过getMethods()/getDeclaredMethods()获取类的成员函数
         * getMethods(): 获取所有pubic的函数，包括父类继承而来的
         * getDeclaredMethods(): 获取所有该类自己声明的方法，不访问父类继承的
         * */
        /** 要获取类的信息，首先要获取类的类类型 */
        Class c = obj.getClass();
        System.out.println(String.format("类的名称是：%s", c.getName()));
        /**获取类的方法*/
        Method[] methods = c.getDeclaredMethods(); //c.getMethods();
        for (Method method:methods) {
          /**获取类方法的返回值*/
          Class returnType = method.getReturnType();
          System.out.println(String.format("类%s的%s方法的返回值类的类类型是:%s", c.getName(), method.getName(), returnType));
          /**获取类方法的入参*/
          Class[] paramTypes = method.getParameterTypes();
          for (Class paramType:paramTypes) {
              System.out.println(String.format("方法%s的参数列表的类型的类类型是：%s", method.getName(), paramType.getName()));
          }
        }

        System.out.println("-----");

        /**
         * 3. 通过getFields()/getDeclaredFields()获取类的成员变量
         */
        Class cc = obj.getClass();
        Field[] fs = c.getDeclaredFields(); //c.getFields();
        for (Field field:fs) {
            /**得到成员变量类型的类类型*/
            Class fieldType = field.getType();
            String typeName = fieldType.getName();
            /**得到成员变量的名称*/
            String fieldName = field.getName();
            System.out.println(String.format("%s, %s", typeName, fieldName));
        }

        System.out.println("-----");

        /**
         * 4. 通过getConstructors()/getDeclaredConstructors()获取对象的构造函数
         */
        Class cd = obj.getClass();
        Constructor[] cs = cd.getDeclaredConstructors(); //cd.getConstructors();
        for (Constructor constructor:cs) {
            System.out.print(String.format("%s (", constructor.getName()));
            Class[] paramTypes = constructor.getParameterTypes();
            for (Class class1: paramTypes) {
                System.out.print(String.format("%s, ", class1.getName()));
            }
            System.out.println(")");
        }
    }

    /**
     * 方法的反射
     * 1.如何获取某个方法？
     *  方法的名称和方法的参数列表才能唯一决定某个方法
     * 2.方法的反射的操作
     *  method.invoke(对象, 参数列表);
     */
    public static void methodInvoke() {
        PrintUtil pu = new PrintUtil();
        /**想要获取一个方法就要先获取类的信息
         * 获取类的信息首先要获取类的类类型*/
        Class c = pu.getClass();
        try {
            Method method1 = c.getMethod("println");
            method1.invoke(pu);

            /**一个方法由该方法的名称和参数列表决定*/
            Method method2 = c.getMethod("println", int.class, int.class);
            /**方法的反射操作，若有返回值会返回具体的返回值*/
            method2.invoke(pu, 1, 2);

            Method method3 = c.getMethod("println", String.class, String.class);
            method3.invoke(pu, "Jack", "Rose");
        } catch (NoSuchMethodException | InvocationTargetException | IllegalAccessException e) {
            e.printStackTrace();
        }
    }

    /**
     *
     */
    public static void genericityCheckTest() {
       List list = new ArrayList();
       List<String> lists = new ArrayList<String>();
       lists.add("abc");
       //list.add(10); //因为指定了String类型，这句会报编译时错误

       /**以下返回true说明，运行时泛型被擦除了*/
       System.out.println(list.getClass() == lists.getClass());

       Class c = lists.getClass();
        try {
            Method method = c.getMethod("add", Object.class);
            /**反射是在运行时，此处会绕过编译期间的泛型检查*/
            method.invoke(lists, 20);
        } catch (NoSuchMethodException | InvocationTargetException | IllegalAccessException e) {
            e.printStackTrace();
        }
        /**以下这句会报错java.lang.ClassCastException: java.lang.Integer cannot be cast to java.lang.String
         * but why?
         * */
        //lists.stream().forEach(System.out::println);
        for (Object elem: lists) {
            System.out.println(elem);
        }
    }

    public static void main(String[] args) {

        //classType();

        //classLoader("JavaPractice.Bird");

        //classInformation(new Person());

        //methodInvoke();

        genericityCheckTest();

    }
}

class Person {
    Person() {}

    Person(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    private String name;
}

interface Animal {
    public void go();
}

class Bird implements Animal {

    @Override
    public void go() {
        System.out.println("fly...");
    }
}

class Dog implements Animal {

    @Override
    public void go() {
        System.out.println("run...");
    }
}

class PrintUtil {
    public void println() {
        System.out.println("Hello Baby.");
    }

    public void println(int a, int b) {
        System.out.println(String.format("%d + %d = %d", a, b, a+b));
    }

    public void println(String a, String b) {
        System.out.println(String.format("%s, %s", a, b));
    }

}