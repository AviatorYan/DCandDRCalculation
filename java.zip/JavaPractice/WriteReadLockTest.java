package JavaPractice;

import java.util.concurrent.locks.ReadWriteLock;
import java.util.concurrent.locks.ReentrantReadWriteLock;

/**
 * Created by 10192078 on 2017/3/10.
 */
public class WriteReadLockTest {

    /**ReentrantReadWriteLock里面提供了很多丰富的方法, 不过最主要的有两个方法：readLock()和writeLock()用来获取读锁和写锁。*/
    private ReadWriteLock rwl = new ReentrantReadWriteLock();

    static {
        System.out.print("");
    }

    public static void main(String[] args) {
        final WriteReadLockTest test = new WriteReadLockTest();

        new Thread() {
            @Override
            public void run() {
                //test.getS(Thread.currentThread());
                test.getL(Thread.currentThread());
            }
        }.start();

        new Thread() {
            @Override
            public void run() {
                //test.getS(Thread.currentThread());
                test.getL(Thread.currentThread());
            }
        }.start();
    }

    public synchronized void getS(Thread thread) {
        long start = System.currentTimeMillis();
        while (System.currentTimeMillis() - start <= 1) {
            System.out.println(String.format("%s 正在进行读操作", thread.getName()));
        }
        System.out.println(String.format("%s 读操作完毕", thread.getName()));
    }

    public void getL(Thread thread) {
        rwl.readLock().lock();
        try {
            long start = System.currentTimeMillis();
            while (System.currentTimeMillis() - start <= 1) {
                System.out.println(String.format("%s 正在进行读操作", thread.getName()));
            }
            System.out.println(String.format("%s 读操作完毕", thread.getName()));
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            rwl.readLock().unlock();
        }
    }
}
