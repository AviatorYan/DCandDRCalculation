package JavaPractice;

/**
 * Created by 10192078 on 2017/3/7.
 */
public class Factory {
    public static void main(String[] args) {
        ComputerEngineer ce = new ComputerEngineer();
        ce.builtComputer(1, 1);
    }
}

class ComputerEngineer {
    private Cpu cpu;
    private MainBoard mainBoard;

    public void builtComputer(int cpuStyle, int mainBoardStyle) {
        /**装好电脑*/
        builtUp(cpuStyle, mainBoardStyle);
        /**测试电脑*/
        Testing();
    }

    private void builtUp(int cpuStyle, int mainBoardStyle){
        cpu = CpuFactory.createCpu(cpuStyle);
        mainBoard = MainBoardFactory.createMainBoard(mainBoardStyle);
        //System.out.println(String.format("cpu: %s\nmainboard: %s", cpu.getClass().getName(), mainBoard.getClass().getName()));
    }

    private void Testing(){
        cpu.calculate();
        mainBoard.installCPU();
    }
}

interface Cpu {
    public void calculate();
}

class IntelCpu implements Cpu {
    private int pin = 0;

    public IntelCpu(int p){
        this.pin = p;
    }

    @Override
    public void calculate() {
        System.out.println(String.format("CPU针脚个数：%s", pin));
    }
}

class AmdCpu implements Cpu {
    private int pin = 0;

    AmdCpu(int pin) {
        this.pin = pin;
    }

    @Override
    public void calculate() {
        System.out.println(String.format("CPU针脚个数：%s", pin));
    }
}

/**
 * CPU工厂，用于创建具体的CPU类
 */
class CpuFactory {
    public static Cpu createCpu(int style) {
        Cpu cpu = null;
        if (style == 1) {
            cpu = new IntelCpu(755);
        } else if (style == 2) {
            cpu = new AmdCpu(946);
        }
        return cpu;
    }
}

interface MainBoard {
    public void installCPU();
}

class IntelMainBoard implements MainBoard {
    private int pinHole = 0;

    IntelMainBoard(int pinHole) {
        this.pinHole = pinHole;
    }

    @Override
    public void installCPU() {
        System.out.println(String.format("主板针孔个数：%s", pinHole));
    }
}

class AmdMainBoard implements MainBoard {
    private int pinHole = 0;

    AmdMainBoard(int pinHole) {
        this.pinHole = pinHole;
    }

    @Override
    public void installCPU() {
        System.out.println(String.format("主板针孔个数：%s", pinHole));
    }
}

/**
 * 主板工厂，用于创建具体的主板类
 */
class MainBoardFactory {
    public static MainBoard createMainBoard(int style) {
        MainBoard mainBoard = null;
        if (style == 1) {
            mainBoard = new IntelMainBoard(755);
        } else if (style ==2) {
            mainBoard = new AmdMainBoard(946);
        }
        return mainBoard;
    }
}
