package JavaPractice;

import java.io.UnsupportedEncodingException;
import java.net.URL;
import java.net.URLEncoder;

/**
 * Created by 10192078 on 2017/4/25.
 */
public class StringTest {

    public static boolean isChinese(char c) {
        Character.UnicodeBlock ub = Character.UnicodeBlock.of(c);
        return ub == Character.UnicodeBlock.CJK_UNIFIED_IDEOGRAPHS
                || ub == Character.UnicodeBlock.CJK_COMPATIBILITY_IDEOGRAPHS
                || ub == Character.UnicodeBlock.CJK_UNIFIED_IDEOGRAPHS_EXTENSION_A
                || ub == Character.UnicodeBlock.GENERAL_PUNCTUATION
                || ub == Character.UnicodeBlock.CJK_SYMBOLS_AND_PUNCTUATION
                || ub == Character.UnicodeBlock.HALFWIDTH_AND_FULLWIDTH_FORMS;
    }

    public static String urlEncode(String str) {
        char[] ch = str.toCharArray();
        StringBuilder sb = new StringBuilder();

        try {
            for (char c : ch) {
                if (isChinese(c)) {
                    String s = Character.toString(c);
                    sb.append(URLEncoder.encode(s, "UTF-8"));
                } else {
                    sb.append(c);
                }
            }
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }
        return sb.toString();
    }


    public static void main(String[] args) {
        String result = urlEncode("/[asdf四川");
        try {
            String result2 = URLEncoder.encode("/[asdf四川", "UTF-8");
            System.out.println(result2);
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }
        System.out.println(result);
    }

}
