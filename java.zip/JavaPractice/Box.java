package JavaPractice;

/**
 * Created by 10192078 on 2017/2/22.
 */
public class Box<T> {
    private T t;

    public void add(T t) {
        this.t = t;
    }

    public T get() {
        return t;
    }
}
