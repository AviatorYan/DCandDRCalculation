package JavaPractice;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.concurrent.locks.*;

/**
 * Created by 10192078 on 2017/3/10.
 */
public class LockTest {

    private ArrayList<Integer> arrayList = new ArrayList<>();
    /**此处Lock对象是类的成员变量，是类对象共享的*/
    private Lock lock = new ReentrantLock();

    public static void main(String[] args) {
        LockTest test = new LockTest();

        new Thread() {
            @Override
            public void run() {
                test.insert(Thread.currentThread());
            }
        }.start();

        new Thread() {
            @Override
            public void run() {
                test.insert(Thread.currentThread());
            }
        }.start();

    }

    public void insert(Thread thread) {
        /**lock是insert方法的局部变量，每一个insert方法都保留有一份副本,无法实现预期的加锁任务*/
        //Lock lock = new ReentrantLock();
        //if (lock.tryLock()) {}
        //lock.lockInterruptibly();
        lock.lock();
        try {
            System.out.println(String.format("%s 得到了锁", thread.getName()));
            Arrays.asList(1, 2, 3, 4, 5).forEach(arrayList::add);
        } catch (Exception e) {
            //todo handle exception
        } finally {
            System.out.println(String.format("%s 释放了锁", thread.getName()));
            lock.unlock();
        }
    }
}
