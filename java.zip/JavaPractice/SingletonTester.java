package JavaPractice;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;

/**
 * Created by 10192078 on 2017/4/6.
 */
public class SingletonTester {
    public static void main(String[] args) {
        Singleton_1 ins = Singleton_1.getInstance();
        System.out.println(ins.getClass().getName());

        Singleton_2 ins_2 = Singleton_2.getInstance();
        System.out.println(ins_2.getClass().getName());

        Singleton_3 ins_3 = Singleton_3.getInstance();
        System.out.println(ins_3.getClass().getName());

        Singleton_4 ins_4 = Singleton_4.getInstance();
        System.out.println(ins_4.getClass().getName());

        Singleton_5 ins_5 = Singleton_5.getInstance();
        System.out.println(ins_5.getClass().getName());

        Singleton_6 ins_6 = Singleton_6.getInstance();
        System.out.println(ins_6.getClass().getName());
        Singleton_6 ins_66 = Singleton_6.getInstance();
        System.out.println(ins_6 == ins_66);

        Singleton_7 ins_7 = Singleton_7.getInstance;
        System.out.println(ins_7);
        ins_7.setName("asdf");
        System.out.println(ins_7.getName());
        ins_7.print();

        new fc();

        /**通过反射获取类的私有化构造器*/
        Constructor[] cs = Singleton_1.class.getDeclaredConstructors();
        Constructor dc = cs[0];
        dc.setAccessible(true);
        try {
            Singleton_1 st = (Singleton_1)dc.newInstance();
            System.out.println(st.getClass().getName());
        } catch (InstantiationException | IllegalAccessException | InvocationTargetException e) {
            e.printStackTrace();
        }

        /**通过枚举实现的单例实例无法通过反射进行攻击
         * 因为枚举无法通过反射来创建实例
         *
         * 由java.lang.reflect.Constructor的newInstance()方法识别并抛出异常来禁止了通过反射构造枚举对象
         * */
        Constructor[] cs_1 = Singleton_7.class.getDeclaredConstructors();
        Constructor dc_1 = cs_1[0];
        dc_1.setAccessible(true);
        try {
            Singleton_7 st_1 = (Singleton_7)dc_1.newInstance("asdf", 0);
            System.out.println(st_1.getClass().getName());
        } catch (InstantiationException | IllegalAccessException | InvocationTargetException e) {
            e.printStackTrace();
        }

    }
}

final class fc {}

/**
 * 饿汉式单例
 * 优点：简单，确保了即使在多线程环境中也只有一个实例
 * 缺点：在程序运行时，即使未被使用，该实例也已被创建，对内存紧张的程序不够优化
 */
class Singleton_1 {
    /**需要私有化构造函数，防止外部实例化该类的对象，从而确保只有一个实例*/
    private Singleton_1(){}

    private static Singleton_1 instance = new Singleton_1();

    public static Singleton_1 getInstance() {
        return instance;
    }
}

/**
 * 懒汉式单例
 * 优点：实例在需要的时候才被创建，对内存友好
 * 缺点：在多线程环境中，线程不安全，会出现返回非单一实例的情况
 */
class Singleton_2 {
    private Singleton_2() {}

    private static Singleton_2 instance = null;

    public static Singleton_2 getInstance() {
        if (instance == null) {
            instance = new Singleton_2();
        }
        return instance;
    }
}

/**
 * 线程安全的懒汉式单例
 * 缺点：由于synchronized关键字的限制，执行效率会比较低
 */
class Singleton_3 {
    private Singleton_3() {}

    private static Singleton_3 instance = null;

    public static synchronized Singleton_3 getInstance() {
        if (instance == null) {
            instance = new Singleton_3();
        }
        return instance;
    }
}

/**
 * 不推荐使用
 * 双重检测(DCL)实现单例模式
 * 缺点：实现麻烦，在Java1.5后才有用，因为Java1.5以前对于volatile关键字的实现存在问题
 */
class Singleton_5 {
    private Singleton_5() {}

    /**volatile确保instance变量在多线程环境下的正确运行，屏蔽了编译器对其的优化(防止指令重排序)*/
    private volatile static Singleton_5 instance = null;

    public static Singleton_5 getInstance() {
        if (instance == null) { //第一次检测
            synchronized (Singleton_5.class) {
                if (instance == null) { //第二次检测
                    instance = new Singleton_5();
                }
            }
        }
        return instance;
    }
}

/**
 * 假的双重检测单例模式
 * 实际上与Singleton_3是大致一样的
 */
class Singleton_4 {
    private Singleton_4() {}

    private volatile static Singleton_4 instance = null;

    public static Singleton_4 getInstance() {
        synchronized (Singleton_4.class) {
            if (instance == null) {
                instance = new Singleton_4();
            }
            return instance;
        }
    }
}

/**
 * 推荐使用
 * Initialization on Demand Holder(IoDH)技术实现单例模式
 * 优点：延迟加载(实例instance并不是Singleton_6的成员变量，而是静态内部类HolderClass的)
 *      线程安全(Java虚拟机来保证)
 * 缺点：与编程语言本身的特性相关，很多面向对象语言不支持
 *
 *
 * PS：在以下情况，JVM隐含地执行了同步，不需要自己使用synchronized来加互斥锁进行同步控制
 * 1. 有静态初始化器(在静态字段上或static{}块中的初始化器)初始化数据时
 * 2. 访问final字段时
 * 3. 在创建线程之前创建对象时
 * 4. 线程可以看见它将要处理的对象时
 */
class Singleton_6 {
    private Singleton_6() {}

    /**通过静态内部类创建单实例**/
    /**
     * 类级的内部类，也就是静态的成员式内部类，该内部类的实例与外部类的实例
     * 没有绑定关系，而且只有被调用时才会装载，从而实现了延迟加载
     */
    private static class HolderClass {
        /**静态初始化器，由JVM来保证线程安全*/
        private final static Singleton_6 instance = new Singleton_6();
    }

    public static Singleton_6 getInstance() {
        return HolderClass.instance;
    }
}

/**
 * 极推荐使用
 * 枚举实现单例模式(枚举也是一种特殊的类，因此可以包含成员变量和成员方法，但构造器不能是public的)
 * 优点：1.线程安全；2.防止反序列化而产生新实例；3.防止反射攻击
 */
enum Singleton_7 {
    /**定义一个枚举的元素，代表了一个实例*/
    getInstance {
        @Override
        public void print() {
            System.out.println("abcdef");
        }
    };

    public abstract void print();

    private Singleton_7() {}

    /**以下可以定义一些该实例可以做的操作*/
    private String name;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
