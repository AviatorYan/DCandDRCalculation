package JavaPractice;

import java.util.Date;

/**
 * Created by 10192078 on 2017/3/8.
 */
public class ThreadLockTest {

    public static final String obj1 = "obj1";
    public static final String obj2 = "obj2";

    public static void main(String[] args) {
        LockA la = new LockA();
        new Thread(la).start();

        LockB lb = new LockB();
        new Thread(lb).start();

    }
}

class LockA implements Runnable {

    @Override
    public void run() {
        System.out.println(String.format("%s: LockA开始执行.",new Date().toString()));

        try {
            while (true) {
                synchronized (ThreadLockTest.obj1) {
                    System.out.println(String.format("%s: LockA锁住obj1.", new Date().toString()));
                    Thread.sleep(3000);
                    synchronized (ThreadLockTest.obj2) {
                        System.out.println(String.format("%s: LockA锁住obj2.", new Date().toString()));
                        Thread.sleep(60 * 1000);
                    }
                }
            }
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}

class LockB implements Runnable {
    @Override
    public void run() {
        System.out.println(String.format("%s: LockB开始执行", new Date().toString()));
        try {
            synchronized (ThreadLockTest.obj2) {
                System.out.println(String.format("%s: LockB锁住obj2.",new Date().toString()));
                Thread.sleep(3000);
                synchronized (ThreadLockTest.obj1) {
                    System.out.println(String.format("%s: LockB锁住obj1.",new Date().toString()));
                    Thread.sleep(60 * 1000);
                }
            }
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}
