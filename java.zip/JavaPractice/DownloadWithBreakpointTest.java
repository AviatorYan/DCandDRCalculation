package JavaPractice;

import encrypt.MD5;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.RandomAccessFile;
import java.net.HttpURLConnection;
import java.net.URL;

/**
 * Created by 10192078 on 2017/4/12.
 */
public class DownloadWithBreakpointTest {
    /**
     * @param args
     */
    public static void main(String[] args) {
        HttpURLConnection httpURLConnection = null;
        URL url = null;
        BufferedInputStream bis = null;
        byte[] buf = new byte[10240];
        int size = 0;
        String fileName = "api_networkoptimization_highinterferenceoverlapgrid_四川_成都_day_20160510.gzip";
        String filePath = "D:\\ZXVMAX\\CODE\\branch\\V6.15.50.02\\vmax-openapi\\vmax-openapi-webapp";
        String timestamp = "2017-04-1310:39:45";
        String username = "DEV_version_asdf";
        String sign = MD5.md5Sign(username, timestamp);
        String remoteUrl= "http://localhost:26188/vmaxadvanced/api/networkoptimization/download/880F5C9DDB994F32B447B848B9/api_networkoptimization_highinterferenceoverlapgrid_%E5%9B%9B%E5%B7%9D_%E6%88%90%E9%83%BD_day_20160510.gzip?appkey=2C8C2F15FC066BDDC780CA19E2B3F2CE&timestamp=" + timestamp + "&sign=" + sign;

        System.out.println(remoteUrl);

        // 检查本地文件
        RandomAccessFile rndFile = null;
        File file = new File(filePath + "\\" + fileName);
        long localFileSize = 0;
        if (file.exists()) {
            localFileSize = file.length();
        } else {
            // 建立文件
            try {
                file.createNewFile();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        // 下载文件
        try {
            url = new URL(remoteUrl);
            httpURLConnection = (HttpURLConnection)url.openConnection();
            // 设置User-Agent
            httpURLConnection.setRequestProperty( "User-Agent", "Net");
            // 设置续传开始
            System. out.println( "本地文件大小：" +localFileSize);
            setHeader(httpURLConnection);
            httpURLConnection.setRequestProperty( "Range", "bytes=" + localFileSize  + "-" );
            // 获取输入流
            bis = new BufferedInputStream(httpURLConnection.getInputStream());

            long remoteFileSize = httpURLConnection.getContentLength();
            System.out.println( "返回结果码：" + httpURLConnection.getHeaderField("result"));
            //System.out.println("文件名："+httpURLConnection.getHeaderField("Content-Disposition"));
            if (localFileSize < remoteFileSize) {
                if (localFileSize==0) {
                    System. out.println( "文件不存在，开始下载..." );
                } else {
                    System. out.println( "文件续传..." );
                }
            } else {
                System. out.println( "文件存在，重新下载..." );
                file.delete();
                try {
                    file.createNewFile();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }

            rndFile = new RandomAccessFile(filePath + "\\" + fileName, "rw");

            rndFile.seek(localFileSize);
            int i = 0;
            //while ((size = bis.read(buf)) != -1 && i < 1) {
            while ((size = bis.read(buf)) != -1) {
                //if (i > 500) break;
                rndFile.write(buf, 0, size);
                i++;
            }
            System. out.println( "i = " + i);
            httpURLConnection.disconnect();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /*
     * 为一个HttpURLConnection模拟请求头，伪装成一个浏览器发出的请求
     */
    private static void setHeader(HttpURLConnection con) {
        con.setRequestProperty(
                "User-Agent",
                "Mozilla/5.0 (X11; U; Linux i686; en-US; rv:1.9.0.3) Gecko/2008092510 Ubuntu/8.04 (hardy) Firefox/3.0.3");
        con.setRequestProperty("Accept-Language", "en-us,en;q=0.7,zh-cn;q=0.3");
        con.setRequestProperty("Accept-Encoding", "aa");
        con.setRequestProperty("Accept-Charset",
                "ISO-8859-1,utf-8;q=0.7,*;q=0.7");
        con.setRequestProperty("Keep-Alive", "300");
        con.setRequestProperty("Connection", "keep-alive");
        con.setRequestProperty("If-Modified-Since",
                "Fri, 02 Jan 2009 17:00:05 GMT");
        con.setRequestProperty("If-None-Match", "\"1261d8-4290-df64d224\"");
        con.setRequestProperty("Cache-Control", "max-age=0");
        con.setRequestProperty("Referer",
                "http://www.skycn.com/soft/14857.html");
    }

}

