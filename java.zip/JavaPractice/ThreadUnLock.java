package JavaPractice;

import java.util.Date;
import java.util.concurrent.Semaphore;
import java.util.concurrent.TimeUnit;

/**
 * 使用信号量Semaphore可以防止线程的死锁
 *
 * Created by 10192078 on 2017/3/8.
 */
public class ThreadUnLock {

    public static Semaphore a1 = new Semaphore(1);
    public static Semaphore a2 = new Semaphore(2);

    public static void main(String[] args) {
        LockA1 la = new LockA1();
        new Thread(la).start();

        LockB1 lb = new LockB1();
        new Thread(lb).start();
    }
}

class LockA1 implements Runnable{

    @Override
    public void run() {
        System.out.println(String.format("%s: LockA开始执行.",new Date().toString()));
        try {
            while (true) {
                /**acquire()将会获取一个许可*/
                if (ThreadUnLock.a1.tryAcquire(1, TimeUnit.SECONDS)) {
                    System.out.println(String.format("%s: LockA锁住obj1.",new Date().toString()));
                    if (ThreadUnLock.a2.tryAcquire(1, TimeUnit.SECONDS)) {
                        System.out.println(String.format("%s: LockA锁住obj2.",new Date().toString()));
                        Thread.sleep(60 * 1000);
                    } else {
                        System.out.println(String.format("%s: LockA锁obj2失败.",new Date().toString()));
                    }
                } else {
                    System.out.println(String.format("%s: LockA锁obj1失败.",new Date().toString()));
                }
                /**release()将会释放一个许可*/
                ThreadUnLock.a1.release();  //释放一个许可
                ThreadUnLock.a2.release();
            }
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}


class LockB1 implements Runnable {

    @Override
    public void run() {
        System.out.println(String.format("%s: LockB开始执行.",new Date().toString()));
        try {
            while (true) {
                if (ThreadUnLock.a2.tryAcquire(1, TimeUnit.SECONDS)) {
                    System.out.println(String.format("%s: LockB锁住obj2.",new Date().toString()));
                    if (ThreadUnLock.a1.tryAcquire(1, TimeUnit.SECONDS)) {
                        System.out.println(String.format("%s: LockB锁住obj1.",new Date().toString()));
                        Thread.sleep(60 * 1000);
                    } else {
                        System.out.println(String.format("%s: LockB锁obj1失败.",new Date().toString()));
                    }
                } else {
                    System.out.println(String.format("%s: LockB锁obj2失败.",new Date().toString()));
                }
                ThreadUnLock.a1.release();
                ThreadUnLock.a2.release();
            }
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}


