package JVMTest;

/**
 * Created by 10192078 on 2016/10/17.
 */
public class ThreadLockedTest  implements Runnable {
    @Override
    public void run() {
        synchronized (this) {
            for (int i = 0; i < 10; i--) {
                System.out.println(Thread.currentThread().getName() + " synchronized loop " + i);
            }
        }
    }

    public static void main(String[] args) {
        ThreadLockedTest t1 = new ThreadLockedTest();
        Thread ta = new Thread(t1, "A");
        Thread tb = new Thread(t1, "B");
        ta.start();
        tb.start();
    }


}
