package JavaPractice;

import org.apache.poi.ss.formula.functions.T;

import java.lang.reflect.Array;
import java.util.*;
import java.util.function.*;

/**
* Created by 10192078 on 2017/2/24.
*/
public class Java8Tester {

    private static void sortUsingJava8(List<String> names) {
        Collections.sort(names, (s1, s2) -> s1.compareTo(s2));
    }

    private static int operate(int a, int b, MathOperation mathOperation) {
        return mathOperation.operation(a, b);
    }

    private static <T> void eval(List<T> list, Predicate<T> predicate) {
        for (T elem: list) {
            if (predicate.test(elem)) {
                System.out.println(elem);
            }
        }
    }

    public static void main(String[] args) {
        /**Java8编程风格，偏函数式*/
        /*List<String> names1 = new ArrayList<String>();
        names1.add("Google");
        names1.add("Facebook");
        names1.add("Amazon");
        names1.add("Apple");
        Java8Tester.sortUsingJava8(names1);
        System.out.println(names1);*/

        /**stream&方法引用*/
        List<String> list = new ArrayList<String>();
        list.add("a");
        list.add("b");
        list.add("c");
        list.forEach(System.out::print);

        /**默认方法*/
        /*Car vehicle = new Car();
        vehicle.print();
        vehicle.printBaseInfo();*/

        /**lambda*/
        /*MathOperation addition = (int a, int b) -> a + b;
        MathOperation subtraction = (a, b) -> a - b;
        MathOperation multiplication = (int a, int b) -> {return a * b;};
        MathOperation division = (int a, int b) -> a / b;
        Java8Tester.operate(1, 2, addition);
        addition.operation(1, 2);*/

        /**函数式接口*/
        /*List<Integer> list = Arrays.asList(1, 2, 3, 4, 5, 6);
        eval(list, x -> x % 2 ==0);*/

        Integer i = null;
        Optional<Integer> oi =  Optional.ofNullable(i);
        oi.isPresent();
        oi.orElse(0);
    }
}

interface Vehicle {
    default void print() {
        System.out.println("我是一辆车.");
    }

    /*static void blowHorn() {
        System.out.println("按喇叭.");
    }*/
}

interface FourWheeler {
    default void print() {
        System.out.println("我是一辆四轮的车.");
    }
}

class Car implements Vehicle, FourWheeler {
    public void print() {
        System.out.println("我是一辆四个轮子的汽车");
    }

    void printBaseInfo() {
        Vehicle.super.print();
        FourWheeler.super.print();
    }
}

interface MathOperation {
    int operation(int a, int b);
}
