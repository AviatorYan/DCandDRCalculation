package JavaPractice;

import java.io.*;

/**
 * Created by 10192078 on 2017/3/7.
 */
public class SerializableTest {

    public static void output2File() {
        PersonSer jack = new PersonSer("Jack", 26, "13700000000", "ShenZhen");
        try {
            FileOutputStream fos = new FileOutputStream(new File("chenjx/person.ser"));
            ObjectOutputStream oos = new ObjectOutputStream(fos);
            oos.writeObject(jack);
            oos.close();
            fos.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void inputFromFile() {
        try {
            FileInputStream fis = new FileInputStream(new File("chenjx/person.ser"));
            ObjectInputStream ois = new ObjectInputStream(fis);
            PersonSer jack = (PersonSer)ois.readObject();
            jack.print();
            System.out.println(jack.some);
            ois.close();
            fis.close();
        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        output2File();
        inputFromFile();
    }
}

class Basic {
    public int some = 10;
}

class PersonSer extends Basic implements Serializable {
    private String name;
    private int age;
    /**transient关键字修饰的成员变量不会被序列化*/
    private transient String telephone;
    private String address;

    /**成员变量serialVersionUID确保了不同的两个PersonSer是否能够被成功序列化与反序列化*/
    private static final long serialVersionUID = 1L;

    PersonSer(String name, int age, String telephone, String address) {
        //super(some);
        this.name = name;
        this.age = age;
        this.telephone = telephone;
        this.address = address;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getTelephone() {
        return telephone;
    }

    public void setTelephone(String telephone) {
        this.telephone = telephone;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public void print() {
        System.out.println(String.format("name: %s, age: %s, telephone: %s, address: %s", name, age, telephone, address));
    }
}
