package JavaPractice;

/**
 * Created by 10192078 on 2017/3/7.
 */
public class AbstractFactory {
    public static void main(String[] args) {
        AbFactory af = new AmdFactory();
        Engineer e = new Engineer();
        e.buildComputer(af);
    }
}

class Engineer {
    private Cpu cpu;
    private MainBoard mainBoard;

    public void buildComputer(AbFactory af) {
        /**装好电脑*/
        builtUp(af);
        /**测试电脑*/
        Testing();
    }

    private void Testing() {
        cpu.calculate();
        mainBoard.installCPU();
    }

    private void builtUp(AbFactory af) {
        cpu = af.createCpu();
        mainBoard = af.createMainBoard();
    }

}

interface AbFactory {
    public Cpu createCpu();
    public MainBoard createMainBoard();
}

class IntelFactory implements AbFactory {
    @Override
    public Cpu createCpu() {
        return new IntelCpu(755);
    }

    @Override
    public MainBoard createMainBoard() {
        return new IntelMainBoard(755);
    }
}

class AmdFactory implements AbFactory {
    @Override
    public Cpu createCpu() {
        return new AmdCpu(946);
    }

    @Override
    public MainBoard createMainBoard() {
        return new AmdMainBoard(946);
    }
}