package JVMTest;

/**
 * Created by 10192078 on 2016/12/27.
 */
public class IfDef {

    public static void main(String[] args) {
        if (true) {
           System.out.println("Block 1");
        } else {
           System.out.println("Block 2");
        }

//        while (false) {
//            System.out.println("");
//        }
    }
}
