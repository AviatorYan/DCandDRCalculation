package JavaPractice;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by 10192078 on 2017/3/6.
 */
public class ObserverTester {

    public static void main(String[] args) {
        Observer observer1 = new ConcreteObserver();
        Observer observer2 = new ConcreteObserver();
        ConcreteSubject subject = new ConcreteSubject();
        subject.attach(observer1);
        subject.attach(observer2);
        subject.change("asdf");
    }
}


/**
 * 抽象主题角色类
 */
class Subject {
    /**用来保存注册的观察者对象*/
    List<Observer> observerList = new ArrayList<>();

    /**
     * 注册观察者对象
     * @param observer
     */
    public void attach(Observer observer) {
        observerList.add(observer);
    }

    /**
     * 删除观察者对象
     * @param observer
     */
    public void detach(Observer observer) {
        observerList.remove(observer);
    }

    /**
     * 通知所有注册的观察者对象
     * 1. 推模型
     * 2. 取模型
     * @param
     */
    /*public void notifyChange(String newInfo) {
        for (Observer observer:observerList) {
            observer.update(newInfo);
        }
    }*/

    public void notifyChange() {
        for (Observer observer:observerList) {
            observer.update(this);
        }
    }
}

/**
 * 具体主题角色类
 */
class ConcreteSubject extends Subject {
    String info = "";

    /**
     * 更改状态的函数
     * @param info
     */
    public void change(String info) {
        this.info = info;
        /** 状态发生改变，将通知各个观察者 */
        this.notifyChange();
        System.out.println(String.format("I'm in %s, info is %s", this.getClass().getName(), this.info));
    }

    public String getInfo() {
        return info;
    }
}


/**
 * 抽象观察者角色类/接口
 */
class Observer {
    /**
     * 更新接口
     * @param subject
     */
    public void update(Subject subject) {}
}


/**
 * 具体观察者角色类
 */
class ConcreteObserver extends Observer {
    /** 观察者的状态 */
    String info = "";

    /**
     * 具体实现的更新操作
     * 1. 推模型
     * 2. 取模型
     * @param newInfo
     */
    /*public void update(String newInfo) {
        *//** 更新观察者的状态，使其与目标的状态保持一致 *//*
        info = newInfo;
        System.out.println(String.format("I'm in %s, my info is %s", this.getClass().getName(), info));
    }*/

    public void update(Subject subject) {
        /** 更新观察者的状态，使其与目标的状态保持一致 */
        info = ((ConcreteSubject)subject).getInfo();
        System.out.println(String.format("I'm in %s, my info is %s", this.getClass().getName(), info));
    }
}
