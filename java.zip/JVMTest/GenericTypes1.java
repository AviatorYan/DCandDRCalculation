package JVMTest;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by 10192078 on 2016/12/27.
 */
public class GenericTypes1 {
//    public static String method(List<String> list) {
//        System.out.println("invoke method(List<String) list");
//        return "";
//    }
//
//    public static int method(List<Integer> list) {
//        System.out.println("invoke method(List<invoke> list)");
//        return 1;
//    }
//
//    public static void main(String[] args) {
//        method(new ArrayList<String>());
//        method(new ArrayList<Integer>());
//    }

}
