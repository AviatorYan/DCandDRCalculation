package JVMTest;

import java.util.Vector;
import java.util.concurrent.locks.Lock;

/**
 * Created by 10192078 on 2016/9/28.
 */
public class ThreadSafeTest {
    private static Vector<Integer> vector = new Vector<Integer>();

    public static void main(String[] args) {
        while (true) {
            for (int i = 0; i < 10; i++) {
                vector.add(i);
            }

            Thread removeThread = new Thread(new Runnable() {
                @Override
                public void run() {
                    //synchronized (vector) {
                        for (int i = 0; i < vector.size(); i++) {
                            vector.remove(i);
                        }
                //    }
                }
            });

            Thread printThread = new Thread(new Runnable() {
                @Override
                public void run() {
                    //synchronized (vector) {
                        for (Integer aVector : vector) {
                            System.out.print(aVector);
                        }
                //    }
                }
            });

            removeThread.start();
            printThread.start();

            while (Thread.activeCount() > 20);
        }
    }
}
